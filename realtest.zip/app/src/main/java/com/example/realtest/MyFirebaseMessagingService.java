package com.example.realtest;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";
    private static final String CHANNEL_ID = "fcm_default_channel";

    // 새로운 FCM 토큰이 생성될 때 호출됩니다.
    @Override
    public void onNewToken(String token) {
        super.onNewToken(token);
        Log.d(TAG, "FCM Registration Token: " + token);

        // 서버에 새 토큰을 전송하거나 로컬에 저장하는 로직을 추가하세요.
        sendRegistrationToServer(token);
    }

    // 받은 메시지를 처리하는 부분
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        Log.d(TAG, "Message received from: " + remoteMessage.getFrom());

        // 알림 제목과 내용 설정
        String title = remoteMessage.getNotification() != null ? remoteMessage.getNotification().getTitle() : "기본 제목";
        String message = remoteMessage.getNotification() != null ? remoteMessage.getNotification().getBody() : "기본 내용";

        // 알림 채널 생성
        createNotificationChannel();

        // 알림 빌더 생성
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification) // 알림 아이콘이 없는 경우 기본 아이콘으로 대체하세요.
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        // 알림 표시
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(1, builder.build()); // 고유 알림 ID 사용
    }

    // 서버로 토큰을 보내는 로직 (옵션)
    private void sendRegistrationToServer(String token) {
        // 서버에 토큰을 저장하는 로직을 작성하세요.
    }

    // 알림 채널을 만드는 메서드 (Android 8.0 이상 필수)
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "FCM Channel";
            String description = "Channel for FCM notifications";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }
}
